// src/smoke.test.js
describe('runner', () => {
  it('ejecuta al menos este test', () => {
    expect(true).toBeTrue();
  });
});
