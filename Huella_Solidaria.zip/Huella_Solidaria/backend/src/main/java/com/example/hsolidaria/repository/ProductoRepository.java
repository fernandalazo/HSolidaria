package com.example.hsolidaria.repository;

import com.example.hsolidaria.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
}
